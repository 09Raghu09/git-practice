package com.db.grad.javaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
